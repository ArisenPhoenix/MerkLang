#pragma once

// #include "core/types.h"
#include "core/TypesFWD.hpp"
#include "core/callables/Callable.hpp" 
#include "core/callables/classes/Method.hpp"


class NativeMethod : public Method {
private:
    std::function<Node(ArgumentList args, SharedPtr<Scope> callScope, SharedPtr<ClassInstanceNode> self)> methodFn;

public:
    NativeMethod(
        String name,
        ParamList params,
        SharedPtr<Scope> classScope,
        std::function<Node(ArgumentList args, SharedPtr<Scope> callScope, SharedPtr<ClassInstanceNode> self)> methodFn 
    );

    ~NativeMethod() override;
                
    Node execute(ArgumentList args,
                 SharedPtr<Scope> callScope,
                 SharedPtr<ClassInstanceNode> instanceNode = nullptr) const override;

    String toString() const override;

    SharedPtr<CallableSignature> toCallableSignature() override;
    void setCapturedScope(SharedPtr<Scope> scope) override;
    SharedPtr<Scope> getCapturedScope() const override;
    void setScope(SharedPtr<Scope> newScope) const override;
    virtual MethodBody* getThisBody();
    virtual UniquePtr<CallableBody> getBody() override;
    virtual CallableBody* getBody() const override;
    virtual CallableBody* getInvocableBody() override;
};
