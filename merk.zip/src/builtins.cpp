#include "core/TypesFWD.hpp"
#include "core/builtins.h"


std::unordered_map<String, SharedPtr<ClassBase>> getNativeClasses(SharedPtr<Scope> scope) {
    return getAllNativeClasses(scope);
}


std::unordered_map<String, SharedPtr<CallableSignature>> getNativeFunctions(SharedPtr<Scope> scope) {
    return getAllNativeFunctions(scope);
}
